package com.test.lolinformation.ui.gameplay

import com.test.lolinformation.ui.base.BaseViewModel

class GamePlayViewModel : BaseViewModel() {

}
