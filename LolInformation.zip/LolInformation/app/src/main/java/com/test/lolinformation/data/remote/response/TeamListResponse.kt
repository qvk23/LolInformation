package com.test.lolinformation.data.remote.response

import com.test.lolinformation.data.local.model.Team

class TeamListResponse: BaseListResponse<Team>()
