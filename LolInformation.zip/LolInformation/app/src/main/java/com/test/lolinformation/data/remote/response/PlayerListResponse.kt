package com.test.lolinformation.data.remote.response

import com.test.lolinformation.data.local.model.Player

class PlayerListResponse: BaseListResponse<Player>()
