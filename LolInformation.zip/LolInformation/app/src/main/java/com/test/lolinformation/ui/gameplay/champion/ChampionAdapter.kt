package com.test.lolinformation.ui.gameplay.champion

import androidx.recyclerview.widget.DiffUtil
import com.test.lolinformation.R
import com.test.lolinformation.data.local.model.Champion
import com.test.lolinformation.databinding.ItemChampionBinding
import com.test.lolinformation.ui.base.BaseRecyclerAdapter

class ChampionAdapter :
    BaseRecyclerAdapter<Champion, ItemChampionBinding>(object : DiffUtil.ItemCallback<Champion>() {
        override fun areItemsTheSame(oldItem: Champion, newItem: Champion) =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: Champion, newItem: Champion) = oldItem == newItem

    }) {
    override val layoutId: Int = R.layout.item_champion

}