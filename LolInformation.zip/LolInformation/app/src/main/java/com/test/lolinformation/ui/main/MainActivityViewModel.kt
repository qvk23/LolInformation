package com.test.lolinformation.ui.main

import com.test.lolinformation.ui.base.BaseViewModel

class MainActivityViewModel : BaseViewModel() {}
