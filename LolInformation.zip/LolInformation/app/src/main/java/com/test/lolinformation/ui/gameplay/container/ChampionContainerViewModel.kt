package com.test.lolinformation.ui.gameplay.container

import com.test.lolinformation.data.repository.GamePlayRepository
import com.test.lolinformation.ui.base.BaseViewModel

class ChampionContainerViewModel() : BaseViewModel() {

}
