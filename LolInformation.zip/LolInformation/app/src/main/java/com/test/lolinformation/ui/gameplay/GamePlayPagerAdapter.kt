package com.test.lolinformation.ui.gameplay

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.test.lolinformation.ui.gameplay.container.ChampionContainerFragment

class GamePlayPagerAdapter(fragmentManager: FragmentManager) :
    FragmentPagerAdapter(fragmentManager) {

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> ChampionContainerFragment.newInstance()
            else -> ChampionContainerFragment.newInstance()
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> CHAMPION
            1 -> ITEM
            else -> CHAMPION
        }
    }

    override fun getCount(): Int = NUM_PAGER

    companion object {
        const val NUM_PAGER = 2
        const val CHAMPION = "Champion"
        const val ITEM = "Item"
    }
}
