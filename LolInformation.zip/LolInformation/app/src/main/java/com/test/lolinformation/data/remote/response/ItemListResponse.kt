package com.test.lolinformation.data.remote.response

import com.test.lolinformation.data.local.model.Item

class ItemListResponse: BaseListResponse<Item>()
